/******/ (() => {
    // webpackBootstrap
    /******/ "use strict";
    /******/    var e = {
        /***/ 574: 
        /***/ function(e, t, r) {
            var o = this && this.__decorate || function(e, t, r, o) {
                var i, n = arguments.length, a = n < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, o); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (a = (n < 3 ? i(a) : n > 3 ? i(t, r, a) : i(t, r)) || a);
                return n > 3 && a && Object.defineProperty(t, r, a), a;
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.CreateSpeciesModule = void 0;
            const i = r(415), n = r(854), a = r(417);
            let s = class CreateSpeciesModule {};
            s = o([ (0, i.Module)({
                imports: [ n.SpeciesDynamoDBModule.forStoring(), n.SpeciesDynamoDBModule.forFinding() ],
                providers: [ a.CreateSpeciesServices ],
                exports: [ a.CreateSpeciesServices ]
            }) ], s), t.CreateSpeciesModule = s;
        },
        /***/ 417: 
        /***/ function(e, t, r) {
            var o = this && this.__decorate || function(e, t, r, o) {
                var i, n = arguments.length, a = n < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, o); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (a = (n < 3 ? i(a) : n > 3 ? i(t, r, a) : i(t, r)) || a);
                return n > 3 && a && Object.defineProperty(t, r, a), a;
            }, i = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            }, n = this && this.__param || function(e, t) {
                return function(r, o) {
                    t(r, o, e);
                };
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.CreateSpeciesServices = void 0;
            const a = r(415), s = r(296), c = r(932), p = r(578);
            let l = class CreateSpeciesServices {
                constructor(e, t) {
                    this.writingRepository = e, this.finderRepository = t;
                }
                async create(e) {
                    if (await this.finderRepository.findByName(e.name)) throw new Error(`Ya existe una especie con ese nombre ${e.name}`);
                    const t = Object.assign(new p.SpeciesEntity, e);
                    await this.writingRepository.create(t);
                }
            };
            l = o([ (0, a.Injectable)(), n(0, (0, a.Inject)(c.WritingRepository)), n(1, (0, 
            a.Inject)(s.FinderRepository)), i("design:paramtypes", [ Object, Object ]) ], l), 
            t.CreateSpeciesServices = l;
        },
        /***/ 880: 
        /***/ (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.BaseEntity = void 0;
            const o = r(726);
            t.BaseEntity = class BaseEntity {
                constructor() {
                    this.identifier = new o.Identifier;
                }
            };
        }
        /***/ ,
        /***/ 726: 
        /***/ (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.Identifier = void 0;
            const o = r(828);
            class Identifier {
                constructor(e) {
                    e && (this._id = e);
                }
                get id() {
                    return this._id;
                }
                static generate() {
                    const e = (0, o.v4)();
                    return new Identifier(e);
                }
            }
            t.Identifier = Identifier;
        }
        /***/ ,
        /***/ 961: 
        /***/ (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.isTranslatable = t.Translatable = void 0, r(236);
            const o = Symbol("Translatable");
            t.Translatable = function() {
                return Reflect.metadata(o, "public");
            }, t.isTranslatable = function(e, t) {
                return !!Reflect.getMetadata(o, e, t);
            };
        }
        /***/ ,
        /***/ 296: 
        /***/ (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.FinderRepository = void 0, t.FinderRepository = Symbol("FinderRepository");
        }
        /***/ ,
        /***/ 932: 
        /***/ (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.WritingRepository = void 0, t.WritingRepository = Symbol("WritingRepository");
        }
        /***/ ,
        /***/ 578: 
        /***/ function(e, t, r) {
            var o = this && this.__decorate || function(e, t, r, o) {
                var i, n = arguments.length, a = n < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, o); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (a = (n < 3 ? i(a) : n > 3 ? i(t, r, a) : i(t, r)) || a);
                return n > 3 && a && Object.defineProperty(t, r, a), a;
            }, i = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpeciesEntity = void 0;
            const n = r(880), a = r(961);
            class SpeciesEntity extends n.BaseEntity {
                constructor() {
                    super();
                }
            }
            o([ (0, a.Translatable)(), i("design:type", Number) ], SpeciesEntity.prototype, "average_height", void 0), 
            o([ (0, a.Translatable)(), i("design:type", Number) ], SpeciesEntity.prototype, "average_lifespan", void 0), 
            o([ (0, a.Translatable)(), i("design:type", String) ], SpeciesEntity.prototype, "classification", void 0), 
            o([ (0, a.Translatable)(), i("design:type", String) ], SpeciesEntity.prototype, "designation", void 0), 
            o([ (0, a.Translatable)(), i("design:type", Array) ], SpeciesEntity.prototype, "eye_colors", void 0), 
            o([ (0, a.Translatable)(), i("design:type", Array) ], SpeciesEntity.prototype, "hair_colors", void 0), 
            o([ (0, a.Translatable)(), i("design:type", String) ], SpeciesEntity.prototype, "homeworld", void 0), 
            o([ (0, a.Translatable)(), i("design:type", String) ], SpeciesEntity.prototype, "language", void 0), 
            o([ (0, a.Translatable)(), i("design:type", String) ], SpeciesEntity.prototype, "name", void 0), 
            o([ (0, a.Translatable)(), i("design:type", Array) ], SpeciesEntity.prototype, "skin_colors", void 0), 
            t.SpeciesEntity = SpeciesEntity;
        },
        /***/ 385: 
        /***/ function(e, t, r) {
            var o = this && this.__decorate || function(e, t, r, o) {
                var i, n = arguments.length, a = n < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, o); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (a = (n < 3 ? i(a) : n > 3 ? i(t, r, a) : i(t, r)) || a);
                return n > 3 && a && Object.defineProperty(t, r, a), a;
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.CreateSpeciesAppModule = void 0;
            const i = r(415), n = r(574), a = r(151);
            let s = class CreateSpeciesAppModule {};
            s = o([ (0, i.Module)({
                imports: [ n.CreateSpeciesModule ],
                controllers: [ a.CreateSpeciesController ]
            }) ], s), t.CreateSpeciesAppModule = s;
        },
        /***/ 151: 
        /***/ function(e, t, r) {
            var o = this && this.__decorate || function(e, t, r, o) {
                var i, n = arguments.length, a = n < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, o); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (a = (n < 3 ? i(a) : n > 3 ? i(t, r, a) : i(t, r)) || a);
                return n > 3 && a && Object.defineProperty(t, r, a), a;
            }, i = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            }, n = this && this.__param || function(e, t) {
                return function(r, o) {
                    t(r, o, e);
                };
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.CreateSpeciesController = void 0;
            const a = r(415), s = r(417), c = r(582);
            let p = class CreateSpeciesController {
                constructor(e) {
                    this.service = e;
                }
                findByName(e) {
                    return this.service.create(e);
                }
            };
            o([ (0, a.Post)(), n(0, (0, a.Body)()), i("design:type", Function), i("design:paramtypes", [ c.CreateSpeciesInputDto ]), i("design:returntype", void 0) ], p.prototype, "findByName", null), 
            p = o([ (0, a.Controller)("/species"), i("design:paramtypes", [ s.CreateSpeciesServices ]) ], p), 
            t.CreateSpeciesController = p;
        },
        /***/ 582: 
        /***/ function(e, t, r) {
            var o = this && this.__decorate || function(e, t, r, o) {
                var i, n = arguments.length, a = n < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, o); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (a = (n < 3 ? i(a) : n > 3 ? i(t, r, a) : i(t, r)) || a);
                return n > 3 && a && Object.defineProperty(t, r, a), a;
            }, i = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.CreateSpeciesInputDto = void 0;
            const n = r(849);
            class CreateSpeciesInputDto {}
            o([ (0, n.IsNumber)(), (0, n.Min)(0), i("design:type", Number) ], CreateSpeciesInputDto.prototype, "average_height", void 0), 
            o([ (0, n.IsNumber)(), (0, n.Min)(1), i("design:type", Number) ], CreateSpeciesInputDto.prototype, "average_lifespan", void 0), 
            o([ (0, n.IsString)(), (0, n.IsNotEmpty)(), i("design:type", String) ], CreateSpeciesInputDto.prototype, "classification", void 0), 
            o([ (0, n.IsString)(), (0, n.IsNotEmpty)(), i("design:type", String) ], CreateSpeciesInputDto.prototype, "designation", void 0), 
            o([ (0, n.IsArray)(), (0, n.ArrayNotEmpty)(), (0, n.ArrayMinSize)(1), (0, n.IsString)({
                each: !0
            }), i("design:type", Array) ], CreateSpeciesInputDto.prototype, "eye_colors", void 0), 
            o([ (0, n.IsArray)(), (0, n.ArrayNotEmpty)(), (0, n.ArrayMinSize)(1), (0, n.IsString)({
                each: !0
            }), i("design:type", Array) ], CreateSpeciesInputDto.prototype, "hair_colors", void 0), 
            o([ (0, n.IsString)(), (0, n.IsNotEmpty)(), i("design:type", String) ], CreateSpeciesInputDto.prototype, "homeworld", void 0), 
            o([ (0, n.IsString)(), (0, n.IsNotEmpty)(), i("design:type", String) ], CreateSpeciesInputDto.prototype, "language", void 0), 
            o([ (0, n.IsString)(), (0, n.IsNotEmpty)(), i("design:type", String) ], CreateSpeciesInputDto.prototype, "name", void 0), 
            o([ (0, n.IsArray)(), (0, n.ArrayNotEmpty)(), (0, n.ArrayMinSize)(1), (0, n.IsString)({
                each: !0
            }), i("design:type", Array) ], CreateSpeciesInputDto.prototype, "skin_colors", void 0), 
            t.CreateSpeciesInputDto = CreateSpeciesInputDto;
        },
        /***/ 281: 
        /***/ function(e, t, r) {
            var o = this && this.__decorate || function(e, t, r, o) {
                var i, n = arguments.length, a = n < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, o); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (a = (n < 3 ? i(a) : n > 3 ? i(t, r, a) : i(t, r)) || a);
                return n > 3 && a && Object.defineProperty(t, r, a), a;
            }, i = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.DynamoDBMapper = void 0;
            const n = r(110), a = r(415), s = r(336);
            let c = class DynamoDBMapper {
                constructor() {
                    let e = new s.DynamoDB;
                    "dev" == process.env.ENV && (e = new s.DynamoDB({
                        region: "localhost",
                        endpoint: process.env.DYNAMODB_LOCAL_URL
                    })), this.mapper = new n.DataMapper({
                        client: e
                    });
                }
                getMapper() {
                    return this.mapper;
                }
            };
            c = o([ (0, a.Injectable)(), i("design:paramtypes", []) ], c), t.DynamoDBMapper = c;
        },
        /***/ 653: 
        /***/ function(e, t, r) {
            var o = this && this.__decorate || function(e, t, r, o) {
                var i, n = arguments.length, a = n < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, o); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (a = (n < 3 ? i(a) : n > 3 ? i(t, r, a) : i(t, r)) || a);
                return n > 3 && a && Object.defineProperty(t, r, a), a;
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.DynamoDBModule = void 0;
            const i = r(415), n = r(281);
            let a = class DynamoDBModule {};
            a = o([ (0, i.Module)({
                imports: [],
                providers: [ n.DynamoDBMapper ],
                exports: [ n.DynamoDBMapper ]
            }) ], a), t.DynamoDBModule = a;
        },
        /***/ 460: 
        /***/ (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpeciesDynamoDBMapper = void 0;
            const o = r(726), i = r(578), n = r(952);
            t.SpeciesDynamoDBMapper = class SpeciesDynamoDBMapper {
                static fromEntity(e) {
                    const t = Object.assign(new n.SpeciesSchema, e);
                    return t.edited = "", t.created = "", t;
                }
                static fromSchema(e) {
                    const t = Object.assign(new i.SpeciesEntity, e);
                    return t.identifier = new o.Identifier(e.name), t;
                }
            };
        }
        /***/ ,
        /***/ 536: 
        /***/ function(e, t, r) {
            var o = this && this.__decorate || function(e, t, r, o) {
                var i, n = arguments.length, a = n < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, o); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (a = (n < 3 ? i(a) : n > 3 ? i(t, r, a) : i(t, r)) || a);
                return n > 3 && a && Object.defineProperty(t, r, a), a;
            }, i = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpeciesDynamoDBCreationRepository = void 0;
            const n = r(415), a = r(281), s = r(460);
            let c = class SpeciesDynamoDBCreationRepository {
                constructor(e) {
                    this.mapper = e;
                }
                async create(e) {
                    const t = s.SpeciesDynamoDBMapper.fromEntity(e);
                    return t.created = (new Date).toISOString(), await this.mapper.getMapper().put(t), 
                    e;
                }
            };
            c = o([ (0, n.Injectable)(), i("design:paramtypes", [ a.DynamoDBMapper ]) ], c), 
            t.SpeciesDynamoDBCreationRepository = c;
        },
        /***/ 912: 
        /***/ function(e, t, r) {
            var o = this && this.__decorate || function(e, t, r, o) {
                var i, n = arguments.length, a = n < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, o); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (a = (n < 3 ? i(a) : n > 3 ? i(t, r, a) : i(t, r)) || a);
                return n > 3 && a && Object.defineProperty(t, r, a), a;
            }, i = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpeciesDynamoDBFinderRepository = void 0;
            const n = r(110), a = r(415), s = r(281), c = r(460), p = r(952);
            let l = class SpeciesDynamoDBFinderRepository {
                constructor(e) {
                    this.mapper = e;
                }
                async findByName(e) {
                    try {
                        const t = await this.mapper.getMapper().get(Object.assign(new p.SpeciesSchema, {
                            name: e
                        }));
                        return c.SpeciesDynamoDBMapper.fromSchema(t);
                    } catch (e) {
                        if (e.name == n.ItemNotFoundException.name) return null;
                        throw e;
                    }
                }
            };
            l = o([ (0, a.Injectable)(), i("design:paramtypes", [ s.DynamoDBMapper ]) ], l), 
            t.SpeciesDynamoDBFinderRepository = l;
        },
        /***/ 854: 
        /***/ function(e, t, r) {
            var o, i = this && this.__decorate || function(e, t, r, o) {
                var i, n = arguments.length, a = n < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, o); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (a = (n < 3 ? i(a) : n > 3 ? i(t, r, a) : i(t, r)) || a);
                return n > 3 && a && Object.defineProperty(t, r, a), a;
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpeciesDynamoDBModule = void 0;
            const n = r(415), a = r(296), s = r(932), c = r(653), p = r(536), l = r(912);
            let d = o = class SpeciesDynamoDBModule {
                static forFinding() {
                    return {
                        module: o,
                        imports: [ c.DynamoDBModule ],
                        providers: [ {
                            provide: a.FinderRepository,
                            useClass: l.SpeciesDynamoDBFinderRepository
                        } ],
                        exports: [ a.FinderRepository ]
                    };
                }
                static forStoring() {
                    return {
                        module: o,
                        imports: [ c.DynamoDBModule ],
                        providers: [ {
                            provide: s.WritingRepository,
                            useClass: p.SpeciesDynamoDBCreationRepository
                        }, {
                            provide: a.FinderRepository,
                            useClass: l.SpeciesDynamoDBFinderRepository
                        } ],
                        exports: [ s.WritingRepository ]
                    };
                }
            };
            d = o = i([ (0, n.Module)({}) ], d), t.SpeciesDynamoDBModule = d;
        },
        /***/ 952: 
        /***/ function(e, t, r) {
            var o = this && this.__decorate || function(e, t, r, o) {
                var i, n = arguments.length, a = n < 3 ? t : null === o ? o = Object.getOwnPropertyDescriptor(t, r) : o;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, r, o); else for (var s = e.length - 1; s >= 0; s--) (i = e[s]) && (a = (n < 3 ? i(a) : n > 3 ? i(t, r, a) : i(t, r)) || a);
                return n > 3 && a && Object.defineProperty(t, r, a), a;
            }, i = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpeciesSchema = void 0;
            const n = r(871);
            let a = class SpeciesSchema {};
            o([ (0, n.hashKey)(), i("design:type", String) ], a.prototype, "name", void 0), 
            o([ (0, n.attribute)(), i("design:type", Number) ], a.prototype, "average_height", void 0), 
            o([ (0, n.attribute)(), i("design:type", Number) ], a.prototype, "average_lifespan", void 0), 
            o([ (0, n.attribute)(), i("design:type", String) ], a.prototype, "classification", void 0), 
            o([ (0, n.attribute)(), i("design:type", String) ], a.prototype, "created", void 0), 
            o([ (0, n.attribute)(), i("design:type", String) ], a.prototype, "edited", void 0), 
            o([ (0, n.attribute)(), i("design:type", String) ], a.prototype, "designation", void 0), 
            o([ (0, n.attribute)(), i("design:type", Array) ], a.prototype, "eye_colors", void 0), 
            o([ (0, n.attribute)(), i("design:type", Array) ], a.prototype, "hair_colors", void 0), 
            o([ (0, n.attribute)(), i("design:type", String) ], a.prototype, "homeworld", void 0), 
            o([ (0, n.attribute)(), i("design:type", String) ], a.prototype, "language", void 0), 
            o([ (0, n.attribute)(), i("design:type", Array) ], a.prototype, "skin_colors", void 0), 
            a = o([ (0, n.table)(process.env.DYNAMODB_TABLE) ], a), t.SpeciesSchema = a;
        },
        /***/ 110: 
        /***/ e => {
            e.exports = require("@aws/dynamodb-data-mapper");
            /***/        },
        /***/ 871: 
        /***/ e => {
            e.exports = require("@aws/dynamodb-data-mapper-annotations");
            /***/        },
        /***/ 415: 
        /***/ e => {
            e.exports = require("@nestjs/common");
            /***/        },
        /***/ 143: 
        /***/ e => {
            e.exports = require("@nestjs/core");
            /***/        },
        /***/ 940: 
        /***/ e => {
            e.exports = require("@vendia/serverless-express");
            /***/        },
        /***/ 336: 
        /***/ e => {
            e.exports = require("aws-sdk");
            /***/        },
        /***/ 849: 
        /***/ e => {
            e.exports = require("class-validator");
            /***/        },
        /***/ 236: 
        /***/ e => {
            e.exports = require("reflect-metadata");
            /***/        },
        /***/ 828: 
        /***/ e => {
            e.exports = require("uuid");
            /***/
            /******/        }
    }, t = {};
    /************************************************************************/
    /******/ // The module cache
    /******/    
    /******/
    /******/ // The require function
    /******/ function r(o) {
        /******/ // Check if module is in cache
        /******/ var i = t[o];
        /******/        if (void 0 !== i) 
        /******/ return i.exports;
        /******/
        /******/ // Create a new module (and put it into the cache)
        /******/        var n = t[o] = {
            /******/ // no module.id needed
            /******/ // no module.loaded needed
            /******/ exports: {}
            /******/        };
        /******/
        /******/ // Execute the module function
        /******/        
        /******/
        /******/ // Return the exports of the module
        /******/ return e[o].call(n.exports, n, n.exports, r), n.exports;
        /******/    }
    /******/
    /************************************************************************/    var o = {};
    // This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
        (() => {
        var e = o;
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.handler = void 0;
        const t = r(415), i = r(143), n = r(940), a = r(385);
        let s = null;
        e.handler = async (e, r, o) => {
            if (!s) {
                const e = await i.NestFactory.create(a.CreateSpeciesAppModule);
                e.useGlobalPipes(new t.ValidationPipe), e.setGlobalPrefix("/api/v1"), await e.init(), 
                s = (0, n.configure)({
                    app: e.getHttpAdapter().getInstance()
                });
            }
            return s(e, r, o);
        };
    })(), module.exports = o;
})
/******/ ();