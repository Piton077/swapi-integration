/******/ (() => {
    // webpackBootstrap
    /******/ "use strict";
    /******/    var e = {
        /***/ 139: 
        /***/ function(e, t, i) {
            var r = this && this.__decorate || function(e, t, i, r) {
                var o, n = arguments.length, a = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (n < 3 ? o(a) : n > 3 ? o(t, i, a) : o(t, i)) || a);
                return n > 3 && a && Object.defineProperty(t, i, a), a;
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.FinderSpeciesModule = void 0;
            const o = i(481), n = i(458), a = i(746), s = i(102), c = i(859), p = i(791);
            let l = class FinderSpeciesModule {};
            l = r([ (0, o.Module)({
                imports: [ c.SpeciesFinderEntiyChainModule ],
                providers: [ {
                    provide: p.FinderSpeciesService,
                    useFactory: e => new p.FinderSpeciesService([ new a.SpanishDictionary, new n.ItalianDictionary ], e),
                    inject: [ s.FinderEntityLink ]
                } ],
                exports: [ p.FinderSpeciesService ]
            }) ], l), t.FinderSpeciesModule = l;
        },
        /***/ 791: 
        /***/ function(e, t, i) {
            var r = this && this.__decorate || function(e, t, i, r) {
                var o, n = arguments.length, a = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (n < 3 ? o(a) : n > 3 ? o(t, i, a) : o(t, i)) || a);
                return n > 3 && a && Object.defineProperty(t, i, a), a;
            }, o = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.FinderSpeciesService = void 0;
            const n = i(481), a = i(31), s = i(102);
            let c = class FinderSpeciesService {
                constructor(e, t) {
                    this.dictionaries = e, this.finderRepository = t;
                }
                async findByName(e, t) {
                    const i = await this.finderRepository.findByName(e);
                    if (!i) throw new Error("Not species found");
                    const r = this.dictionaries.find((e => e.getLanguage() == t));
                    if (!r) throw new Error(`The language ${t} is not available at the moment`);
                    return new a.TranslatorService(r).translate(i);
                }
            };
            c = r([ (0, n.Injectable)(), o("design:paramtypes", [ Array, s.FinderEntityLink ]) ], c), 
            t.FinderSpeciesService = c;
        },
        /***/ 102: 
        /***/ (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.FinderEntityLink = void 0;
            t.FinderEntityLink = class FinderEntityLink {
                constructor(e, t) {
                    this.repository = e, this.isExternal = t;
                }
                async findByName(e) {
                    let t = await this.repository.findByName(e);
                    return t || (this.next ? this.next.findByName(e) : null);
                }
                setNext(e) {
                    this.next = e;
                }
            };
        }
        /***/ ,
        /***/ 859: 
        /***/ function(e, t, i) {
            var r = this && this.__decorate || function(e, t, i, r) {
                var o, n = arguments.length, a = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (n < 3 ? o(a) : n > 3 ? o(t, i, a) : o(t, i)) || a);
                return n > 3 && a && Object.defineProperty(t, i, a), a;
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpeciesFinderEntiyChainModule = void 0;
            const o = i(481), n = i(296), a = i(640), s = i(586), c = i(854), p = i(102);
            let l = class SpeciesFinderEntiyChainModule {};
            l = r([ (0, o.Module)({
                imports: [ c.SpeciesDynamoDBModule.forFinding(), s.SpeciesSWAPIModule ],
                providers: [ {
                    provide: p.FinderEntityLink,
                    useFactory: (e, t) => {
                        const i = new p.FinderEntityLink(e, !1), r = new p.FinderEntityLink(t, !0);
                        return i.setNext(r), i;
                    },
                    inject: [ n.FinderRepository, a.SpeciesSWAPIFinder ]
                } ],
                exports: [ p.FinderEntityLink ]
            }) ], l), t.SpeciesFinderEntiyChainModule = l;
        },
        /***/ 880: 
        /***/ (e, t, i) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.BaseEntity = void 0;
            const r = i(726);
            t.BaseEntity = class BaseEntity {
                constructor() {
                    this.identifier = new r.Identifier;
                }
            };
        }
        /***/ ,
        /***/ 726: 
        /***/ (e, t, i) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.Identifier = void 0;
            const r = i(828);
            class Identifier {
                constructor(e) {
                    e && (this._id = e);
                }
                get id() {
                    return this._id;
                }
                static generate() {
                    const e = (0, r.v4)();
                    return new Identifier(e);
                }
            }
            t.Identifier = Identifier;
        }
        /***/ ,
        /***/ 961: 
        /***/ (e, t, i) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.isTranslatable = t.Translatable = void 0, i(236);
            const r = Symbol("Translatable");
            t.Translatable = function() {
                return Reflect.metadata(r, "public");
            }, t.isTranslatable = function(e, t) {
                return !!Reflect.getMetadata(r, e, t);
            };
        }
        /***/ ,
        /***/ 793: 
        /***/ (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.Dictionary = void 0;
            t.Dictionary = class Dictionary {
                constructor(e) {
                    this.shorthand = e;
                }
                getLanguage() {
                    return this.shorthand;
                }
                mapTranslation(e) {
                    return this.getValues()[e];
                }
            };
        }
        /***/ ,
        /***/ 458: 
        /***/ (e, t, i) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.ItalianDictionary = void 0;
            const r = i(793);
            class ItalianDictionary extends r.Dictionary {
                constructor() {
                    super("it"), this.dict = {
                        average_height: "altezza_media",
                        average_lifespan: "durata_media",
                        classification: "classificazione",
                        created: "creato",
                        designation: "designazione",
                        edited: "modificato",
                        eye_colors: "colori_degli_occhi",
                        hair_colors: "colori_dei_capelli",
                        homeworld: "mondo_nativo",
                        language: "lingua",
                        name: "nome",
                        skin_colors: "colori_della_pelle"
                    };
                }
                getValues() {
                    return this.dict;
                }
            }
            t.ItalianDictionary = ItalianDictionary;
        }
        /***/ ,
        /***/ 746: 
        /***/ (e, t, i) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpanishDictionary = void 0;
            const r = i(793);
            class SpanishDictionary extends r.Dictionary {
                constructor() {
                    super("es"), this.dict = {
                        average_height: "altura_promedio",
                        average_lifespan: "tiempo_vida_estimado",
                        classification: "clasificacion",
                        created: "creado",
                        designation: "designacion",
                        edited: "editado",
                        eye_colors: "color_ojos",
                        hair_colors: "color_pelo",
                        homeworld: "planeta_origen",
                        language: "lenguaje",
                        name: "nombre",
                        skin_colors: "color_piel"
                    };
                }
                getValues() {
                    return this.dict;
                }
            }
            t.SpanishDictionary = SpanishDictionary;
        }
        /***/ ,
        /***/ 296: 
        /***/ (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.FinderRepository = void 0, t.FinderRepository = Symbol("FinderRepository");
        }
        /***/ ,
        /***/ 932: 
        /***/ (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.WritingRepository = void 0, t.WritingRepository = Symbol("WritingRepository");
        }
        /***/ ,
        /***/ 31: 
        /***/ (e, t, i) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.TranslatorService = void 0;
            const r = i(961);
            t.TranslatorService = class TranslatorService {
                constructor(e) {
                    this.dictionary = e;
                }
                translate(e) {
                    const t = {};
                    return Object.keys(e).forEach((i => {
                        const o = this.dictionary.mapTranslation(i);
                        (0, r.isTranslatable)(e, i) && (t[o] = e[i]);
                    })), t;
                }
                setDictionary(e) {
                    this.dictionary = e;
                }
            };
        }
        /***/ ,
        /***/ 578: 
        /***/ function(e, t, i) {
            var r = this && this.__decorate || function(e, t, i, r) {
                var o, n = arguments.length, a = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (n < 3 ? o(a) : n > 3 ? o(t, i, a) : o(t, i)) || a);
                return n > 3 && a && Object.defineProperty(t, i, a), a;
            }, o = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpeciesEntity = void 0;
            const n = i(880), a = i(961);
            class SpeciesEntity extends n.BaseEntity {
                constructor() {
                    super();
                }
            }
            r([ (0, a.Translatable)(), o("design:type", Number) ], SpeciesEntity.prototype, "average_height", void 0), 
            r([ (0, a.Translatable)(), o("design:type", Number) ], SpeciesEntity.prototype, "average_lifespan", void 0), 
            r([ (0, a.Translatable)(), o("design:type", String) ], SpeciesEntity.prototype, "classification", void 0), 
            r([ (0, a.Translatable)(), o("design:type", String) ], SpeciesEntity.prototype, "designation", void 0), 
            r([ (0, a.Translatable)(), o("design:type", Array) ], SpeciesEntity.prototype, "eye_colors", void 0), 
            r([ (0, a.Translatable)(), o("design:type", Array) ], SpeciesEntity.prototype, "hair_colors", void 0), 
            r([ (0, a.Translatable)(), o("design:type", String) ], SpeciesEntity.prototype, "homeworld", void 0), 
            r([ (0, a.Translatable)(), o("design:type", String) ], SpeciesEntity.prototype, "language", void 0), 
            r([ (0, a.Translatable)(), o("design:type", String) ], SpeciesEntity.prototype, "name", void 0), 
            r([ (0, a.Translatable)(), o("design:type", Array) ], SpeciesEntity.prototype, "skin_colors", void 0), 
            t.SpeciesEntity = SpeciesEntity;
        },
        /***/ 965: 
        /***/ function(e, t, i) {
            var r = this && this.__decorate || function(e, t, i, r) {
                var o, n = arguments.length, a = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (n < 3 ? o(a) : n > 3 ? o(t, i, a) : o(t, i)) || a);
                return n > 3 && a && Object.defineProperty(t, i, a), a;
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.GetSpeciesAppModule = void 0;
            const o = i(481), n = i(139), a = i(232);
            let s = class GetSpeciesAppModule {};
            s = r([ (0, o.Module)({
                imports: [ n.FinderSpeciesModule ],
                controllers: [ a.FindSpeciesController ]
            }) ], s), t.GetSpeciesAppModule = s;
        },
        /***/ 232: 
        /***/ function(e, t, i) {
            var r = this && this.__decorate || function(e, t, i, r) {
                var o, n = arguments.length, a = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (n < 3 ? o(a) : n > 3 ? o(t, i, a) : o(t, i)) || a);
                return n > 3 && a && Object.defineProperty(t, i, a), a;
            }, o = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            }, n = this && this.__param || function(e, t) {
                return function(i, r) {
                    t(i, r, e);
                };
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.FindSpeciesController = void 0;
            const a = i(481), s = i(791);
            let c = class FindSpeciesController {
                constructor(e) {
                    this.finderService = e;
                }
                findByName(e, t) {
                    return this.finderService.findByName(e, t);
                }
            };
            r([ (0, a.Get)("/:name"), n(0, (0, a.Param)("name")), n(1, (0, a.Query)("language")), o("design:type", Function), o("design:paramtypes", [ String, String ]), o("design:returntype", void 0) ], c.prototype, "findByName", null), 
            c = r([ (0, a.Controller)("species"), o("design:paramtypes", [ s.FinderSpeciesService ]) ], c), 
            t.FindSpeciesController = c;
        },
        /***/ 640: 
        /***/ function(e, t, i) {
            var r = this && this.__decorate || function(e, t, i, r) {
                var o, n = arguments.length, a = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (n < 3 ? o(a) : n > 3 ? o(t, i, a) : o(t, i)) || a);
                return n > 3 && a && Object.defineProperty(t, i, a), a;
            }, o = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpeciesSWAPIFinder = void 0;
            const n = i(498), a = i(481), s = i(964), c = i(578);
            let p = class SpeciesSWAPIFinder {
                constructor(e) {
                    this.httpService = e;
                }
                async findByName(e) {
                    const {data: t} = await (0, s.firstValueFrom)(this.httpService.get(`${process.env.SWAPI_API_URL}/species`));
                    let i = t.next, r = t.results.find((t => e === t.name));
                    for (;!r && i; ) {
                        const {data: t} = await (0, s.firstValueFrom)(this.httpService.get(`${i}`));
                        r = t.results.find((t => t.name === e)), i = t.next;
                    }
                    return r ? this.mapToEntity(r) : null;
                }
                mapToEntity(e) {
                    const t = new c.SpeciesEntity;
                    return t.average_height = e.average_height, t.average_lifespan = e.average_lifespan, 
                    t.classification = e.classification, t.designation = e.designation, t.eye_colors = "none" == e.eye_colors ? [] : e.eye_colors.split(","), 
                    t.hair_colors = "none" == e.hair_colors ? [] : e.hair_colors.split(","), t.homeworld = e.homeworld, 
                    t.language = e.language, t.name = e.name, t.skin_colors = "none" == e.skin_colors ? [] : e.skin_colors.split(","), 
                    t;
                }
            };
            p = r([ (0, a.Injectable)(), o("design:paramtypes", [ n.HttpService ]) ], p), t.SpeciesSWAPIFinder = p;
        },
        /***/ 586: 
        /***/ function(e, t, i) {
            var r = this && this.__decorate || function(e, t, i, r) {
                var o, n = arguments.length, a = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (n < 3 ? o(a) : n > 3 ? o(t, i, a) : o(t, i)) || a);
                return n > 3 && a && Object.defineProperty(t, i, a), a;
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpeciesSWAPIModule = void 0;
            const o = i(498), n = i(481), a = i(640);
            let s = class SpeciesSWAPIModule {};
            s = r([ (0, n.Module)({
                imports: [ o.HttpModule ],
                providers: [ a.SpeciesSWAPIFinder ],
                exports: [ a.SpeciesSWAPIFinder ]
            }) ], s), t.SpeciesSWAPIModule = s;
        },
        /***/ 281: 
        /***/ function(e, t, i) {
            var r = this && this.__decorate || function(e, t, i, r) {
                var o, n = arguments.length, a = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (n < 3 ? o(a) : n > 3 ? o(t, i, a) : o(t, i)) || a);
                return n > 3 && a && Object.defineProperty(t, i, a), a;
            }, o = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.DynamoDBMapper = void 0;
            const n = i(110), a = i(481), s = i(336);
            let c = class DynamoDBMapper {
                constructor() {
                    let e = new s.DynamoDB;
                    "dev" == process.env.ENV && (e = new s.DynamoDB({
                        region: "localhost",
                        endpoint: process.env.DYNAMODB_LOCAL_URL
                    })), this.mapper = new n.DataMapper({
                        client: e
                    });
                }
                getMapper() {
                    return this.mapper;
                }
            };
            c = r([ (0, a.Injectable)(), o("design:paramtypes", []) ], c), t.DynamoDBMapper = c;
        },
        /***/ 653: 
        /***/ function(e, t, i) {
            var r = this && this.__decorate || function(e, t, i, r) {
                var o, n = arguments.length, a = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (n < 3 ? o(a) : n > 3 ? o(t, i, a) : o(t, i)) || a);
                return n > 3 && a && Object.defineProperty(t, i, a), a;
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.DynamoDBModule = void 0;
            const o = i(481), n = i(281);
            let a = class DynamoDBModule {};
            a = r([ (0, o.Module)({
                imports: [],
                providers: [ n.DynamoDBMapper ],
                exports: [ n.DynamoDBMapper ]
            }) ], a), t.DynamoDBModule = a;
        },
        /***/ 460: 
        /***/ (e, t, i) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpeciesDynamoDBMapper = void 0;
            const r = i(726), o = i(578), n = i(952);
            t.SpeciesDynamoDBMapper = class SpeciesDynamoDBMapper {
                static fromEntity(e) {
                    const t = Object.assign(new n.SpeciesSchema, e);
                    return t.edited = "", t.created = "", t;
                }
                static fromSchema(e) {
                    const t = Object.assign(new o.SpeciesEntity, e);
                    return t.identifier = new r.Identifier(e.name), t;
                }
            };
        }
        /***/ ,
        /***/ 536: 
        /***/ function(e, t, i) {
            var r = this && this.__decorate || function(e, t, i, r) {
                var o, n = arguments.length, a = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (n < 3 ? o(a) : n > 3 ? o(t, i, a) : o(t, i)) || a);
                return n > 3 && a && Object.defineProperty(t, i, a), a;
            }, o = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpeciesDynamoDBCreationRepository = void 0;
            const n = i(481), a = i(281), s = i(460);
            let c = class SpeciesDynamoDBCreationRepository {
                constructor(e) {
                    this.mapper = e;
                }
                async create(e) {
                    const t = s.SpeciesDynamoDBMapper.fromEntity(e);
                    return t.created = (new Date).toISOString(), await this.mapper.getMapper().put(t), 
                    e;
                }
            };
            c = r([ (0, n.Injectable)(), o("design:paramtypes", [ a.DynamoDBMapper ]) ], c), 
            t.SpeciesDynamoDBCreationRepository = c;
        },
        /***/ 912: 
        /***/ function(e, t, i) {
            var r = this && this.__decorate || function(e, t, i, r) {
                var o, n = arguments.length, a = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (n < 3 ? o(a) : n > 3 ? o(t, i, a) : o(t, i)) || a);
                return n > 3 && a && Object.defineProperty(t, i, a), a;
            }, o = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpeciesDynamoDBFinderRepository = void 0;
            const n = i(110), a = i(481), s = i(281), c = i(460), p = i(952);
            let l = class SpeciesDynamoDBFinderRepository {
                constructor(e) {
                    this.mapper = e;
                }
                async findByName(e) {
                    try {
                        const t = await this.mapper.getMapper().get(Object.assign(new p.SpeciesSchema, {
                            name: e
                        }));
                        return c.SpeciesDynamoDBMapper.fromSchema(t);
                    } catch (e) {
                        if (e.name == n.ItemNotFoundException.name) return null;
                        throw e;
                    }
                }
            };
            l = r([ (0, a.Injectable)(), o("design:paramtypes", [ s.DynamoDBMapper ]) ], l), 
            t.SpeciesDynamoDBFinderRepository = l;
        },
        /***/ 854: 
        /***/ function(e, t, i) {
            var r, o = this && this.__decorate || function(e, t, i, r) {
                var o, n = arguments.length, a = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (n < 3 ? o(a) : n > 3 ? o(t, i, a) : o(t, i)) || a);
                return n > 3 && a && Object.defineProperty(t, i, a), a;
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpeciesDynamoDBModule = void 0;
            const n = i(481), a = i(296), s = i(932), c = i(653), p = i(536), l = i(912);
            let d = r = class SpeciesDynamoDBModule {
                static forFinding() {
                    return {
                        module: r,
                        imports: [ c.DynamoDBModule ],
                        providers: [ {
                            provide: a.FinderRepository,
                            useClass: l.SpeciesDynamoDBFinderRepository
                        } ],
                        exports: [ a.FinderRepository ]
                    };
                }
                static forStoring() {
                    return {
                        module: r,
                        imports: [ c.DynamoDBModule ],
                        providers: [ {
                            provide: s.WritingRepository,
                            useClass: p.SpeciesDynamoDBCreationRepository
                        }, {
                            provide: a.FinderRepository,
                            useClass: l.SpeciesDynamoDBFinderRepository
                        } ],
                        exports: [ s.WritingRepository ]
                    };
                }
            };
            d = r = o([ (0, n.Module)({}) ], d), t.SpeciesDynamoDBModule = d;
        },
        /***/ 952: 
        /***/ function(e, t, i) {
            var r = this && this.__decorate || function(e, t, i, r) {
                var o, n = arguments.length, a = n < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, i) : r;
                if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) a = Reflect.decorate(e, t, i, r); else for (var s = e.length - 1; s >= 0; s--) (o = e[s]) && (a = (n < 3 ? o(a) : n > 3 ? o(t, i, a) : o(t, i)) || a);
                return n > 3 && a && Object.defineProperty(t, i, a), a;
            }, o = this && this.__metadata || function(e, t) {
                if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, t);
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.SpeciesSchema = void 0;
            const n = i(871);
            let a = class SpeciesSchema {};
            r([ (0, n.hashKey)(), o("design:type", String) ], a.prototype, "name", void 0), 
            r([ (0, n.attribute)(), o("design:type", Number) ], a.prototype, "average_height", void 0), 
            r([ (0, n.attribute)(), o("design:type", Number) ], a.prototype, "average_lifespan", void 0), 
            r([ (0, n.attribute)(), o("design:type", String) ], a.prototype, "classification", void 0), 
            r([ (0, n.attribute)(), o("design:type", String) ], a.prototype, "created", void 0), 
            r([ (0, n.attribute)(), o("design:type", String) ], a.prototype, "edited", void 0), 
            r([ (0, n.attribute)(), o("design:type", String) ], a.prototype, "designation", void 0), 
            r([ (0, n.attribute)(), o("design:type", Array) ], a.prototype, "eye_colors", void 0), 
            r([ (0, n.attribute)(), o("design:type", Array) ], a.prototype, "hair_colors", void 0), 
            r([ (0, n.attribute)(), o("design:type", String) ], a.prototype, "homeworld", void 0), 
            r([ (0, n.attribute)(), o("design:type", String) ], a.prototype, "language", void 0), 
            r([ (0, n.attribute)(), o("design:type", Array) ], a.prototype, "skin_colors", void 0), 
            a = r([ (0, n.table)(process.env.DYNAMODB_TABLE) ], a), t.SpeciesSchema = a;
        },
        /***/ 110: 
        /***/ e => {
            e.exports = require("@aws/dynamodb-data-mapper");
            /***/        },
        /***/ 871: 
        /***/ e => {
            e.exports = require("@aws/dynamodb-data-mapper-annotations");
            /***/        },
        /***/ 498: 
        /***/ e => {
            e.exports = require("@nestjs/axios");
            /***/        },
        /***/ 481: 
        /***/ e => {
            e.exports = require("@nestjs/common");
            /***/        },
        /***/ 143: 
        /***/ e => {
            e.exports = require("@nestjs/core");
            /***/        },
        /***/ 940: 
        /***/ e => {
            e.exports = require("@vendia/serverless-express");
            /***/        },
        /***/ 336: 
        /***/ e => {
            e.exports = require("aws-sdk");
            /***/        },
        /***/ 236: 
        /***/ e => {
            e.exports = require("reflect-metadata");
            /***/        },
        /***/ 964: 
        /***/ e => {
            e.exports = require("rxjs");
            /***/        },
        /***/ 828: 
        /***/ e => {
            e.exports = require("uuid");
            /***/
            /******/        }
    }, t = {};
    /************************************************************************/
    /******/ // The module cache
    /******/    
    /******/
    /******/ // The require function
    /******/ function i(r) {
        /******/ // Check if module is in cache
        /******/ var o = t[r];
        /******/        if (void 0 !== o) 
        /******/ return o.exports;
        /******/
        /******/ // Create a new module (and put it into the cache)
        /******/        var n = t[r] = {
            /******/ // no module.id needed
            /******/ // no module.loaded needed
            /******/ exports: {}
            /******/        };
        /******/
        /******/ // Execute the module function
        /******/        
        /******/
        /******/ // Return the exports of the module
        /******/ return e[r].call(n.exports, n, n.exports, i), n.exports;
        /******/    }
    /******/
    /************************************************************************/    var r = {};
    // This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
        (() => {
        var e = r;
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.handler = void 0;
        const t = i(143), o = i(940), n = i(965);
        let a = null;
        e.handler = async (e, i, r) => {
            if (!a) {
                const e = await t.NestFactory.create(n.GetSpeciesAppModule);
                e.setGlobalPrefix("/api/v1"), await e.init(), a = (0, o.configure)({
                    app: e.getHttpAdapter().getInstance()
                });
            }
            return a(e, i, r);
        };
    })(), module.exports = r;
})
/******/ ();